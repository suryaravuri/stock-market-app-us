import asyncio
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import text

from app.api.v1.admin_users import router as admin_users_router
from app.api.v1.analysis import router as analysis_router
from app.api.v1.auth import router as auth_router
from app.api.v1.indicators import router as indicators_router
from app.api.v1.market import router as market_router
from app.api.v1.statistics import router as statistics_router
from app.api.v1.stocks import router as stocks_router
from app.api.v1.trading import router as trading_router
from app.api.v1.validation_runs import router as validation_runs_router
from app.api.v1.watchlist_market_sync import (
    router as watchlist_market_sync_router,
)
from app.api.v1.watchlist_monitor import (
    router as watchlist_monitor_router,
)
from app.api.v1.watchlist_scanner import (
    router as watchlist_scanner_router,
)
from app.api.v1.watchlist_stocks import (
    router as watchlist_stocks_router,
)
from app.api.v1.watchlists import router as watchlists_router

from app.core.config import settings
from app.core.database import SessionLocal, engine

# Give only the app's own loggers a handler. (A root basicConfig would
# duplicate every SQLAlchemy echo line when DEBUG=true.)
_app_logger = logging.getLogger("app")
if not _app_logger.handlers:
    _handler = logging.StreamHandler()
    _handler.setFormatter(
        logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    )
    _app_logger.addHandler(_handler)
    _app_logger.setLevel(logging.INFO)
    _app_logger.propagate = False
logger = logging.getLogger(__name__)


def _run_trailing_stop_cycle() -> None:
    # Imported lazily so the app still starts without Alpaca keys.
    from app.brokers.alpaca.trading_client import AlpacaPaperTradingClient
    from app.services.trailing_stop_service import TrailingStopService

    if not AlpacaPaperTradingClient().is_market_open():
        return

    with SessionLocal() as db:
        result = TrailingStopService.sync(db, dry_run=False)

    for item in result.get("positions", []):
        if item.get("action") in {"STOP_RAISED", "STOP_CREATED", "ERROR"}:
            logger.info("Trailing stop %s: %s", item.get("symbol"), item)


def _run_market_sync(force: bool, was_open: bool) -> bool:
    """Returns whether the market is open now. Syncs while open, once
    more right after the close (to store the final 15:45 candle), and
    once at startup to catch up after any downtime."""
    from app.brokers.alpaca.trading_client import AlpacaPaperTradingClient
    from app.services.watchlist_market_sync_service import (
        WatchlistMarketSyncService,
    )

    is_open = AlpacaPaperTradingClient().is_market_open()
    if force or is_open or was_open:
        with SessionLocal() as db:
            result = WatchlistMarketSyncService.sync_all_active(db)
        logger.info(
            "Market sync: %s symbols, %s timeframe syncs, %s errors",
            result["symbols"], result["timeframes_synced"], len(result["errors"]),
        )
        for error in result["errors"][:10]:
            logger.warning("Market sync error: %s", error)
    return is_open


def _seconds_until_next_bar() -> float:
    from datetime import datetime, timezone

    now = datetime.now(timezone.utc)
    seconds_into_bar = (now.minute % 15) * 60 + now.second + now.microsecond / 1e6
    return 15 * 60 - seconds_into_bar + settings.market_sync_delay_seconds


async def _market_sync_loop() -> None:
    force, was_open = True, False   # first pass = startup catch-up
    while True:
        try:
            was_open = await asyncio.to_thread(_run_market_sync, force, was_open)
        except Exception:  # noqa: BLE001 - the loop must survive errors
            logger.exception("Market sync cycle failed")
        force = False
        await asyncio.sleep(_seconds_until_next_bar())


async def _trailing_stop_loop() -> None:
    while True:
        try:
            # Broker + DB calls are blocking; keep them off the event loop.
            await asyncio.to_thread(_run_trailing_stop_cycle)
        except Exception:  # noqa: BLE001 - the loop must survive errors
            logger.exception("Trailing stop cycle failed")
        await asyncio.sleep(settings.trailing_stop_interval_seconds)


@asynccontextmanager
async def lifespan(_app: FastAPI):
    tasks: list[asyncio.Task] = []
    if settings.market_sync_scheduler_enabled:
        tasks.append(asyncio.create_task(_market_sync_loop()))
    if (
        settings.trailing_stop_scheduler_enabled
        and settings.trailing_stop_enabled
        and settings.trading_enabled
        and settings.paper_trading_enabled
        and not settings.live_trading_enabled
    ):
        tasks.append(asyncio.create_task(_trailing_stop_loop()))
    try:
        yield
    finally:
        for task in tasks:
            task.cancel()


app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    debug=settings.debug,
    lifespan=lifespan,
)


# ---------------------------------------------------------
# CORS
# ---------------------------------------------------------

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------------------------------------------------------
# Authentication / Administration
# ---------------------------------------------------------

app.include_router(
    auth_router,
    prefix="/api/v1",
)

app.include_router(
    admin_users_router,
    prefix="/api/v1",
)


# ---------------------------------------------------------
# Application APIs
# ---------------------------------------------------------

app.include_router(
    stocks_router,
    prefix="/api/v1",
)

app.include_router(
    watchlists_router,
    prefix="/api/v1",
)

app.include_router(
    watchlist_stocks_router,
    prefix="/api/v1",
)

app.include_router(
    market_router,
    prefix="/api/v1",
)

app.include_router(
    indicators_router,
    prefix="/api/v1",
)

app.include_router(
    analysis_router,
    prefix="/api/v1",
)

app.include_router(
    trading_router,
    prefix="/api/v1",
)

app.include_router(
    watchlist_scanner_router,
    prefix="/api/v1",
)

app.include_router(
    watchlist_market_sync_router,
    prefix="/api/v1",
)

app.include_router(
    validation_runs_router,
    prefix="/api/v1",
)

app.include_router(
    watchlist_monitor_router,
    prefix="/api/v1",
)

app.include_router(
    statistics_router,
    prefix="/api/v1",
)


# ---------------------------------------------------------
# Health
# ---------------------------------------------------------

@app.get("/health")
def health():
    return {
        "status": "UP",
        "application": settings.app_name,
        "version": settings.app_version,
    }


@app.get("/health/database")
def database_health():
    try:
        with engine.connect() as connection:
            connection.execute(text("SELECT 1"))

        return {
            "status": "UP",
            "database": "PostgreSQL",
        }

    except Exception as exc:
        print(
            "DATABASE CONNECTION ERROR:",
            repr(exc),
        )

        return {
            "status": "DOWN",
            "database": "PostgreSQL",
        }