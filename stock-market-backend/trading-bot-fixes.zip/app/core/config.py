from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict
from sqlalchemy.engine import URL


class Settings(BaseSettings):

    # Application
    app_name: str = "Stock Market Application"
    app_version: str = "1.0.0"
    debug: bool = False

    # PostgreSQL
    database_host: str = "localhost"
    database_port: int = 5433
    database_name: str = "stockmarket"
    database_user: str = "stockuser"
    database_password: str

    # Google Cloud SQL
    cloud_sql_connection_name: str | None = None

    # Redis
    redis_host: str = "localhost"
    redis_port: int = 6379

    # Alpaca
    alpaca_api_key: str
    alpaca_secret_key: str
    alpaca_data_feed: str = "iex"

    # Authentication / JWT
    jwt_secret_key: str
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = 60

    # Trading
    trading_enabled: bool = False
    paper_trading_enabled: bool = False
    live_trading_enabled: bool = False
    auto_trading_enabled: bool = False

    # Risk controls
    account_size: float = 10000.0
    risk_percent: float = 1.0
    max_position_percent: float = 20.0

    # Paper order exits (bracket order legs held by Alpaca)
    paper_use_bracket_orders: bool = True
    default_stop_loss_percent: float = 5.0
    default_take_profit_percent: float = 20.0

    # Trailing stop / profit protection (moves the real Alpaca stop)
    trailing_stop_enabled: bool = True
    # Fallback distance below price; per-stock loss_limit_percent wins.
    trailing_stop_percent: float = 5.0
    # Start trailing once the trade is this % in profit (0 = immediately).
    trailing_activation_percent: float = 0.0
    # Once this % in profit, the stop is locked at entry or better.
    trailing_breakeven_percent: float = 5.0
    # Ignore stop moves smaller than this % (avoids order churn).
    trailing_min_step_percent: float = 0.25
    # In-process loop (local/VM). On Cloud Run use Cloud Scheduler instead.
    trailing_stop_scheduler_enabled: bool = True
    trailing_stop_interval_seconds: int = 60

    # Automatic market-data refresh. The data-quality check fails a symbol
    # once its latest candle is more than 1 bar old, so candles must be
    # refreshed every 15 minutes, not only when a stock is added.
    market_sync_scheduler_enabled: bool = True
    # Wait after each 15-min boundary so Alpaca has finalised the bar.
    market_sync_delay_seconds: int = 90

    @property
    def database_url(self) -> str:
        # Cloud Run + Cloud SQL Unix socket
        if self.cloud_sql_connection_name:
            return URL.create(
                drivername="postgresql+psycopg",
                username=self.database_user,
                password=self.database_password,
                database=self.database_name,
                query={
                    "host": f"/cloudsql/{self.cloud_sql_connection_name}"
                },
            ).render_as_string(hide_password=False)

        # Local development
        return URL.create(
            drivername="postgresql+psycopg",
            username=self.database_user,
            password=self.database_password,
            host=self.database_host,
            port=self.database_port,
            database=self.database_name,
        ).render_as_string(hide_password=False)

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()