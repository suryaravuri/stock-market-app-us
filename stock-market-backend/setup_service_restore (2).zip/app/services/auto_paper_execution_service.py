import logging

from sqlalchemy.orm import Session

from app.core.config import settings
from app.services.paper_trading_service import PaperTradingService

logger = logging.getLogger(__name__)


class AutoPaperExecutionService:
    """
    Automatic STOCK paper-trading execution bridge.

    This service must never submit a LIVE order.
    It is invoked only by an intentional automated workflow after
    SetupService has completed signal/setup evaluation.
    """

    @staticmethod
    def _skip(symbol: str, reason: str) -> dict:
        return {
            "attempted": False,
            "submitted": False,
            "symbol": symbol,
            "mode": "PAPER",
            "reason": reason,
        }

    @staticmethod
    def process_entry(
        *,
        db: Session,
        symbol: str,
        setup: dict,
        current_daily_pnl: float = 0.0,
        max_daily_loss_percent: float = 2.0,
    ) -> dict:

        symbol = symbol.strip().upper()
        skip = AutoPaperExecutionService._skip

        # 1. Automatic execution master switch
        if not settings.auto_trading_enabled:
            return skip(symbol, "AUTO_TRADING_DISABLED")

        # 2. Paper trading must explicitly be enabled
        if not settings.paper_trading_enabled:
            return skip(symbol, "PAPER_TRADING_DISABLED")

        # 3. Fail closed if LIVE trading is enabled.
        if settings.live_trading_enabled:
            return skip(symbol, "LIVE_TRADING_MUST_BE_DISABLED")

        # 4. Signal must have reached ENTRY_CONFIRMED
        lifecycle = setup.get("signal_lifecycle") or {}
        signal_state = str(lifecycle.get("state") or "").upper()

        if signal_state != "ENTRY_CONFIRMED":
            return skip(
                symbol,
                f"SIGNAL_NOT_ENTRY_CONFIRMED:{signal_state or 'UNKNOWN'}",
            )

        # 5. Strategy must independently mark setup actionable
        if not bool(setup.get("actionable")):
            return skip(symbol, "SETUP_NOT_ACTIONABLE")

        # 6. Submit through existing service, re-using the setup that was
        #    just evaluated (no second SetupService run).
        #
        #    Broker/network errors are caught here so one failing symbol
        #    returns a reason instead of aborting the whole watchlist scan.
        try:
            result = PaperTradingService.submit_order(
                db=db,
                symbol=symbol,
                account_size=settings.account_size,
                risk_percent=settings.risk_percent,
                current_daily_pnl=current_daily_pnl,
                max_daily_loss_percent=max_daily_loss_percent,
                setup=setup,
            )
        except Exception as exc:  # noqa: BLE001 - surface any broker error
            logger.exception("Paper order failed for %s", symbol)
            return {
                "attempted": True,
                "submitted": False,
                "symbol": symbol,
                "mode": "PAPER",
                "reason": f"BROKER_ERROR:{type(exc).__name__}: {exc}",
            }

        if not result.get("submitted"):
            result["reason"] = "; ".join(result.get("reasons") or []) or "NOT_SUBMITTED"

        return {
            "attempted": True,
            **result,
        }
