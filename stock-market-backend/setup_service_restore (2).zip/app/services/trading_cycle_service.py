"""One automated trading cycle: sync candles -> scan signals -> paper orders.

Nothing in the app ran this on its own before. Cloud Scheduler calls
POST /api/v1/jobs/trading-cycle every 15 minutes during market hours,
and this service does what a user would otherwise do by clicking:

  1. WatchlistMarketSyncService.sync      (fetch the newest candles)
  2. ValidationWatchlistScanService.scan  (evaluate signals; when
     AUTO_TRADING_ENABLED and PAPER_TRADING_ENABLED are true it submits
     paper orders through AutoPaperExecutionService)
  3. TrailingStopService.sync             (profit protection)

A PostgreSQL advisory lock makes sure two overlapping cycles never run at
the same time, so a slow cycle can't cause duplicate orders.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone

from sqlalchemy import select, text
from sqlalchemy.orm import Session

from app.core.config import settings
from app.market.sessions import (
    INDIA_SESSION,
    US_SESSION,
    MarketSession,
    session_for_stock,
)
from app.models.stock import Stock
from app.models.user import AppUser
from app.models.watchlist import Watchlist, WatchlistStock
from app.services.trailing_stop_service import TrailingStopService
from app.services.validation_run_service import ValidationRunService
from app.services.validation_watchlist_scan_service import (
    ValidationWatchlistScanService,
)
from app.services.watchlist_market_sync_service import WatchlistMarketSyncService

logger = logging.getLogger(__name__)

# Arbitrary constant id for pg_try_advisory_lock
_CYCLE_LOCK_ID = 846_215_001

# Keep running this long after the close so the final candle is picked up.
_AFTER_CLOSE_GRACE = timedelta(minutes=20)

MARKETS: dict[str, MarketSession] = {"US": US_SESSION, "IN": INDIA_SESSION}


class TradingCycleService:

    @staticmethod
    def market_window_open(session: MarketSession, now_utc: datetime) -> bool:
        """True from the open until 20 minutes after the actual close.

        Uses the exchange calendar's real close, so half days
        (e.g. day after Thanksgiving, 1:00 PM ET) are handled.
        """
        local = now_utc.astimezone(session.tz)
        day = local.date()
        if not session.is_session_day(day):
            return False
        open_local = datetime.combine(day, session.open, tzinfo=session.tz)
        close_local = datetime.combine(day, session.close_time_on(day), tzinfo=session.tz)
        return open_local <= local < close_local + _AFTER_CLOSE_GRACE

    @staticmethod
    def _watchlist_markets(db: Session, watchlist_id: int) -> set[str]:
        stocks = db.scalars(
            select(Stock)
            .join(WatchlistStock, WatchlistStock.stock_id == Stock.stock_id)
            .where(
                WatchlistStock.watchlist_id == watchlist_id,
                WatchlistStock.analysis_enabled.is_(True),
                Stock.active.is_(True),
            )
        ).all()
        return {session_for_stock(stock).code for stock in stocks}

    @classmethod
    def run(
        cls,
        db: Session,
        market: str | None = None,
        force: bool = False,
        now: datetime | None = None,
    ) -> dict:
        now_utc = now or datetime.now(timezone.utc)

        locked = db.execute(
            text("SELECT pg_try_advisory_lock(:id)"), {"id": _CYCLE_LOCK_ID}
        ).scalar()
        if not locked:
            logger.warning("Trading cycle skipped: previous cycle still running")
            return {"ran": False, "reason": "PREVIOUS_CYCLE_STILL_RUNNING"}

        try:
            return cls._run_locked(db, market, force, now_utc)
        finally:
            db.execute(text("SELECT pg_advisory_unlock(:id)"), {"id": _CYCLE_LOCK_ID})
            db.commit()

    @classmethod
    def _run_locked(
        cls,
        db: Session,
        market: str | None,
        force: bool,
        now_utc: datetime,
    ) -> dict:
        wanted = {market.upper()} if market else set(MARKETS)
        open_markets = {
            code for code in wanted
            if force or cls.market_window_open(MARKETS[code], now_utc)
        }

        summary: dict = {
            "ran": True,
            "evaluated_at": now_utc,
            "markets_requested": sorted(wanted),
            "markets_open": sorted(open_markets),
            "watchlists": [],
            "paper_orders_submitted": 0,
            "trailing_stops": None,
        }

        if not open_markets:
            summary["reason"] = "MARKETS_CLOSED"
            logger.info("Trading cycle: markets closed (%s)", sorted(wanted))
            return summary

        active_run = ValidationRunService.active(db)
        if active_run is None:
            logger.warning("Trading cycle: no ACTIVE validation run; scans will be skipped")

        watchlists = db.scalars(
            select(Watchlist).where(Watchlist.active.is_(True))
        ).all()

        for watchlist in watchlists:
            item: dict = {
                "watchlist_id": watchlist.watchlist_id,
                "name": watchlist.name,
            }
            summary["watchlists"].append(item)

            markets = cls._watchlist_markets(db, watchlist.watchlist_id)
            if not markets & open_markets:
                item["skipped"] = "NO_STOCKS_IN_OPEN_MARKETS"
                continue

            owner = db.get(AppUser, watchlist.user_id)
            if owner is None:
                item["skipped"] = "OWNER_NOT_FOUND"
                continue

            # 1. Fetch the newest candles as the watchlist's owner
            #    (Indian stocks use that owner's daily Zerodha login).
            try:
                sync = WatchlistMarketSyncService.sync(
                    db=db, watchlist_id=watchlist.watchlist_id, current_user=owner
                )
                item["sync"] = {
                    "successful_stocks": sync["successful_stocks"],
                    "failed_stocks": sync["failed_stocks"],
                    "errors": [
                        {"symbol": s["symbol"], "errors": s["errors"]}
                        for s in sync["stocks"]
                        if s["errors"]
                    ],
                }
            except Exception as exc:  # noqa: BLE001
                db.rollback()
                logger.exception("Sync failed for watchlist %s", watchlist.watchlist_id)
                item["sync_error"] = f"{type(exc).__name__}: {exc}"
                continue

            # 2. Evaluate signals; submits paper orders when enabled.
            if active_run is None:
                item["scan_skipped"] = "NO_ACTIVE_VALIDATION_RUN"
                continue
            try:
                scan = ValidationWatchlistScanService.scan(
                    db=db,
                    validation_run_id=active_run.validation_run_id,
                    watchlist_id=watchlist.watchlist_id,
                )
                submitted = int(scan.get("paper_orders_submitted") or 0)
                summary["paper_orders_submitted"] += submitted
                item["scan"] = {
                    key: scan.get(key)
                    for key in (
                        "scan_status",
                        "symbols_checked",
                        "symbols_scanned",
                        "symbols_blocked_by_data_quality",
                        "actionable_count",
                        "entry_confirmed_count",
                        "paper_execution_enabled",
                        "paper_execution_attempts",
                        "paper_orders_submitted",
                    )
                }
                # Why each blocked symbol was blocked, e.g. STALE_DATA:3_BAR_LAG
                item["blocked"] = {
                    stock["symbol"]: stock.get("decision_reasons")
                    for stock in scan.get("stocks", [])
                    if stock.get("scan_status") == "DATA_QUALITY_BLOCKED"
                }
            except Exception as exc:  # noqa: BLE001
                db.rollback()
                logger.exception("Scan failed for watchlist %s", watchlist.watchlist_id)
                item["scan_error"] = f"{type(exc).__name__}: {exc}"

        # 3. Profit protection for open Alpaca paper positions (US only).
        if "US" in open_markets:
            try:
                summary["trailing_stops"] = TrailingStopService.sync(db, dry_run=False)
            except Exception as exc:  # noqa: BLE001
                db.rollback()
                logger.exception("Trailing stop sync failed")
                summary["trailing_stops"] = {"error": f"{type(exc).__name__}: {exc}"}

        logger.info(
            "Trading cycle done: markets=%s watchlists=%d paper_orders=%d",
            sorted(open_markets),
            len(summary["watchlists"]),
            summary["paper_orders_submitted"],
        )
        return summary
