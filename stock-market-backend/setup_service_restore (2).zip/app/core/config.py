from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict
from sqlalchemy.engine import URL


class Settings(BaseSettings):

    # Application
    app_name: str = "Stock Market Application"
    app_version: str = "1.0.0"
    debug: bool = False

    # PostgreSQL
    database_host: str = "localhost"
    database_port: int = 5433
    database_name: str = "stockmarket"
    database_user: str = "stockuser"
    database_password: str

    # Google Cloud SQL
    cloud_sql_connection_name: str | None = None

    # Redis
    redis_host: str = "localhost"
    redis_port: int = 6379

    # Alpaca
    alpaca_api_key: str
    alpaca_secret_key: str
    alpaca_data_feed: str = "iex"

    # Authentication / JWT
    jwt_secret_key: str
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = 60

    # Trading
    trading_enabled: bool = False
    paper_trading_enabled: bool = False
    live_trading_enabled: bool = False
    auto_trading_enabled: bool = False

    # Shared secret Cloud Scheduler sends in the X-Job-Token header.
    # Leave unset to disable /api/v1/jobs/* entirely.
    job_trigger_token: str | None = None

    # Zerodha (Kite Connect) - REAL MONEY. Everything defaults to OFF/safe.
    kite_api_key: str | None = None
    kite_api_secret: str | None = None
    # Where the backend sends the browser after the Zerodha login callback.
    zerodha_post_login_redirect_url: str = "http://localhost:5173/"
    # Master switch for sending orders to Zerodha at all.
    zerodha_trading_enabled: bool = False
    # When true, orders pass every check and are recorded, but are NOT sent.
    zerodha_dry_run: bool = True
    # Comma-separated app-user emails allowed to place real Zerodha orders.
    zerodha_allowed_user_emails: str = ""
    # Per-order and per-day limits (INR / count), enforced per app user.
    zerodha_max_order_value_inr: float = 10000.0
    zerodha_max_orders_per_day: int = 10
    # Reject LIMIT prices further than this from the last traded price.
    zerodha_max_price_deviation_percent: float = 3.0

    # Risk controls
    account_size: float = 10000.0
    risk_percent: float = 1.0
    max_position_percent: float = 20.0

    # Paper order exits. These were referenced by paper_trading_service.py and
    # trailing_stop_service.py but never defined, so every paper order raised
    # AttributeError just before it reached Alpaca.
    paper_use_bracket_orders: bool = True
    default_stop_loss_percent: float = 5.0     # used when the setup has no valid stop
    default_take_profit_percent: float = 20.0  # used when the setup has no valid target

    # Profit protection (trailing stop)
    trailing_stop_enabled: bool = True
    trailing_stop_percent: float = 5.0         # trail distance below price
    trailing_activation_percent: float = 5.0   # start trailing after +5%
    trailing_breakeven_percent: float = 10.0   # never below entry after +10%
    trailing_min_step_percent: float = 0.25

    # Upstox OAuth callback (must match the Upstox developer console exactly)
    upstox_redirect_uri: str | None = None

    # Backtesting: separate database on the same Postgres server, so replaying
    # history never touches live signal/position tables.
    backtest_database_name: str = "stockmarket_backtest"
    # Alpaca feed for historical bars: "sip" (all exchanges) or "iex".
    backtest_data_feed: str = "sip"
    # Optional: Cloud Run Job that executes backtests ("" = run locally via CLI).
    backtest_job_name: str = ""
    gcp_project_id: str = ""
    gcp_region: str = "us-central1"

    broker_encryption_key: str
    legacy_jwt_key_fallback: bool = True

    @property
    def database_url(self) -> str:
        # Cloud Run + Cloud SQL Unix socket
        if self.cloud_sql_connection_name:
            return URL.create(
                drivername="postgresql+psycopg",
                username=self.database_user,
                password=self.database_password,
                database=self.database_name,
                query={
                    "host": f"/cloudsql/{self.cloud_sql_connection_name}"
                },
            ).render_as_string(hide_password=False)

        # Local development
        return URL.create(
            drivername="postgresql+psycopg",
            username=self.database_user,
            password=self.database_password,
            host=self.database_host,
            port=self.database_port,
            database=self.database_name,
        ).render_as_string(hide_password=False)

    @property
    def backtest_database_url(self) -> str:
        """Same server and credentials as the app database, different database."""
        if self.cloud_sql_connection_name:
            return URL.create(
                drivername="postgresql+psycopg",
                username=self.database_user,
                password=self.database_password,
                database=self.backtest_database_name,
                query={"host": f"/cloudsql/{self.cloud_sql_connection_name}"},
            ).render_as_string(hide_password=False)
        return URL.create(
            drivername="postgresql+psycopg",
            username=self.database_user,
            password=self.database_password,
            host=self.database_host,
            port=self.database_port,
            database=self.backtest_database_name,
        ).render_as_string(hide_password=False)

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )


def zerodha_allowed_emails(value: str) -> set[str]:
    return {item.strip().lower() for item in value.split(",") if item.strip()}


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()