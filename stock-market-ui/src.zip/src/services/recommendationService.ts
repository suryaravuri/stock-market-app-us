import apiClient from "../api/client";
import type { WatchlistScanResponse } from "../types/recommendation";

export const getWatchlistRecommendations =
  async (watchlistId: number): Promise<WatchlistScanResponse> => {
    const response = await apiClient.get<WatchlistScanResponse>(
      `/watchlists/${watchlistId}/scan`
    );

    return response.data;
  };