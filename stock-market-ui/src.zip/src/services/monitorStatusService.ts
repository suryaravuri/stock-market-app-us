import apiClient from "../api/client";
import type { MonitorStatus } from "../types/monitorStatus";

export const getMonitorStatus = async (
  watchlistId: number
): Promise<MonitorStatus> => {
  const response = await apiClient.get<MonitorStatus>(
    `/watchlists/${watchlistId}/monitor-status`
  );

  return response.data;
};