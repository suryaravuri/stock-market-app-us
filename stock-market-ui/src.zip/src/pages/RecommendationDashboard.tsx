import { useEffect, useMemo, useState } from "react";
import RefreshIcon from "@mui/icons-material/Refresh";

import {
  Alert,
  Box,
  Button,
  Chip,
  CircularProgress,
  Container,
  Stack,
  Typography,
} from "@mui/material";

import SummaryCards from "../components/SummaryCards";
import RecommendationTable from "../components/RecommendationTable";

import { getWatchlistRecommendations } from "../services/recommendationService";
import { getMonitorStatus } from "../services/monitorStatusService";

import type {
  RecommendationStock,
  WatchlistScanResponse,
} from "../types/recommendation";

import type { MonitorStatus } from "../types/monitorStatus";

import { useWatchlist } from "../context/WatchlistContext";

function RecommendationDashboard() {
  const [data, setData] = useState<WatchlistScanResponse | null>(null);
  const [monitorStatus, setMonitorStatus] =
    useState<MonitorStatus | null>(null);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

 const { selectedWatchlistId } = useWatchlist();

const loadRecommendations = async (isRefresh = false) => {
  try {
    if (selectedWatchlistId === null) {
      setData(null);
      setMonitorStatus(null);
      setError(null);
      return;
    }

    if (isRefresh) {
      setRefreshing(true);
    } else {
      setLoading(true);
    }

    setError(null);

    const [recommendationResponse, monitorResponse] =
      await Promise.all([
        getWatchlistRecommendations(selectedWatchlistId),
        getMonitorStatus(selectedWatchlistId),
      ]);

    setData(recommendationResponse);
    setMonitorStatus(monitorResponse);
    setLastUpdated(new Date());
  } catch (err: any) {
    console.error(err);

    const detail = err?.response?.data?.detail;

    if (
      err?.response?.status === 404 &&
      typeof detail === "string" &&
      detail.includes("no active analysis-enabled stocks")
    ) {
      // Valid state for a new/empty user's watchlist.
      setData(null);
      setMonitorStatus(null);
      setError(null);
    } else {
      // Genuine API/server/network failure.
      setError("Unable to load recommendation data");
    }
  } finally {
    setLoading(false);
    setRefreshing(false);
  }
};

 useEffect(() => {
  if (selectedWatchlistId === null) {
    return;
  }

  loadRecommendations();
}, [selectedWatchlistId]);

  const summary = useMemo(() => {
    const stocks: RecommendationStock[] = data?.stocks ?? [];

    return {
      strongCount: stocks.filter(
        (stock) => stock.overall_classification === "STRONG"
      ).length,

      watchCount: stocks.filter(
        (stock) => stock.overall_classification === "WATCH"
      ).length,

      avoidCount: stocks.filter(
        (stock) => stock.overall_classification === "AVOID"
      ).length,
    };
  }, [data]);

  if (loading) {
    return (
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          minHeight: "60vh",
        }}
      >
        <Stack spacing={2} sx={{ alignItems: "center" }}>
          <CircularProgress />
          <Typography>Loading recommendations...</Typography>
        </Stack>
      </Box>
    );
  }

  if (
  !loading &&
  !error &&
  selectedWatchlistId !== null &&
  data === null
) {
  return (
    <Box sx={{ py: 4, px: 3 }}>
      <Typography
        variant="h4"
        sx={{ fontWeight: 700, mb: 3 }}
      >
        Recommendation Dashboard
      </Typography>

      <Alert severity="info">
        No analysis-enabled stocks are available in this watchlist.
        Add a stock to your Watchlist and enable Analysis to start
        generating recommendations.
      </Alert>
    </Box>
  );
}

  if (error) {
    return (
      <Container maxWidth="xl" sx={{ mt: 4 }}>
        <Alert severity="error">{error}</Alert>
      </Container>
    );
  }

  if (!data) {
    return null;
  }

  return (
    <Box sx={{ py: 4, px: 3 }}>
      <Stack
        direction={{ xs: "column", sm: "row" }}
        spacing={2}
        sx={{
          justifyContent: "space-between",
          alignItems: {
            xs: "flex-start",
            sm: "center",
          },
          mb: 2,
        }}
      >
        <Box>
          <Typography variant="h4" sx={{ fontWeight: 700 }}>
            Stock Recommendation Monitor
          </Typography>

          <Typography color="text.secondary">
            Watchlist: {data.watchlist_name}
          </Typography>

          <Typography variant="body2" color="text.secondary">
            Last updated:{" "}
            {lastUpdated ? lastUpdated.toLocaleTimeString() : "-"}
          </Typography>

          {monitorStatus && (
            <>
              <Typography variant="body2" color="text.secondary">
                Data ready:{" "}
                {monitorStatus.eligible_for_signal_analysis} /{" "}
                {monitorStatus.symbols_checked}
              </Typography>

              <Typography variant="body2" color="text.secondary">
                Latest candle:{" "}
                {monitorStatus.latest_available_candle
                  ? new Date(
                      monitorStatus.latest_available_candle
                    ).toLocaleTimeString([], {
                      hour: "numeric",
                      minute: "2-digit",
                    })
                  : "N/A"}
              </Typography>
            </>
          )}
        </Box>

        <Stack
          direction="row"
          spacing={2}
          sx={{ alignItems: "center" }}
        >
          {monitorStatus && (
            <Chip
              label={`DATA: ${monitorStatus.data_status}`}
              color={
                monitorStatus.data_status === "PASS"
                  ? "success"
                  : monitorStatus.data_status === "DEGRADED"
                  ? "warning"
                  : "error"
              }
              size="small"
            />
          )}

          <Button
            variant="contained"
            startIcon={<RefreshIcon />}
            disabled={refreshing}
            onClick={() => loadRecommendations(true)}
          >
            {refreshing ? "Refreshing..." : "Refresh"}
          </Button>
        </Stack>
      </Stack>

      {monitorStatus && monitorStatus.data_status !== "PASS" && (
        <Alert
            severity={
            monitorStatus.data_status === "FAIL" ? "error" : "warning"
            }
            sx={{ mb: 2 }}
        >
            <Typography sx={{ fontWeight: 700 }}>
            Market data is{" "}
            {monitorStatus.data_status === "FAIL"
                ? "stale or unavailable"
                : "degraded"}
            </Typography>

            <Typography variant="body2">
            Recommendations may not reflect the latest completed candle.
            </Typography>

            <Typography variant="body2">
            {monitorStatus.eligible_for_signal_analysis} /{" "}
            {monitorStatus.symbols_checked} symbols currently eligible for analysis.
            </Typography>
        </Alert>
        )}

      <SummaryCards
        totalStocks={data.total_stocks}
        actionableCount={data.actionable_count}
        strongCount={summary.strongCount}
        watchCount={summary.watchCount}
        avoidCount={summary.avoidCount}
      />

      <RecommendationTable stocks={data.stocks} />
   </Box>
  );
}

export default RecommendationDashboard;